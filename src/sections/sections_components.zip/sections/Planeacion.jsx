// src/sections/Planeacion.jsx
import React from "react";

export default function Planeacion() {
  return (
    <div className="text-center space-y-4">
      <h1 className="text-5xl font-bold">Planeacion</h1>
      <p className="text-xl text-gray-100">
        Contenido pendiente para la sección: Planeacion
      </p>
    </div>
  );
}
