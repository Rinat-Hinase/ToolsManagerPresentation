// src/sections/Empresa.jsx
import React from "react";

export default function Empresa() {
  return (
    <div className="text-center space-y-4">
      <h1 className="text-5xl font-bold">Empresa</h1>
      <p className="text-xl text-gray-100">
        Contenido pendiente para la sección: Empresa
      </p>
    </div>
  );
}
