// src/sections/Personal.jsx
import React from "react";

export default function Personal() {
  return (
    <div className="text-center space-y-4">
      <h1 className="text-5xl font-bold">Personal</h1>
      <p className="text-xl text-gray-100">
        Contenido pendiente para la sección: Personal
      </p>
    </div>
  );
}
