// src/sections/Ejecucion.jsx
import React from "react";

export default function Ejecucion() {
  return (
    <div className="text-center space-y-4">
      <h1 className="text-5xl font-bold">Ejecucion</h1>
      <p className="text-xl text-gray-100">
        Contenido pendiente para la sección: Ejecucion
      </p>
    </div>
  );
}
