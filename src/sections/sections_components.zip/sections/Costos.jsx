// src/sections/Costos.jsx
import React from "react";

export default function Costos() {
  return (
    <div className="text-center space-y-4">
      <h1 className="text-5xl font-bold">Costos</h1>
      <p className="text-xl text-gray-100">
        Contenido pendiente para la sección: Costos
      </p>
    </div>
  );
}
