// src/sections/Planteamiento.jsx
import React from "react";

export default function Planteamiento() {
  return (
    <div className="text-center space-y-4">
      <h1 className="text-5xl font-bold">Planteamiento</h1>
      <p className="text-xl text-gray-100">
        Contenido pendiente para la sección: Planteamiento
      </p>
    </div>
  );
}
