// src/sections/Calidad.jsx
import React from "react";

export default function Calidad() {
  return (
    <div className="text-center space-y-4">
      <h1 className="text-5xl font-bold">Calidad</h1>
      <p className="text-xl text-gray-100">
        Contenido pendiente para la sección: Calidad
      </p>
    </div>
  );
}
